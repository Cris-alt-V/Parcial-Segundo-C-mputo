from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time
import threading
import wmi
import pythoncom
import os
from db import registrar_evento  # ← Importa desde db.py

# Manejador personalizado
class EventosHandler(FileSystemEventHandler):
    def dispatch(self, event):
        if '~WR' in event.src_path or event.src_path.endswith('.tmp'):
            return
        super().dispatch(event)

    def on_moved(self, event):
        print(f"renombrado de {event.src_path} a {event.dest_path}")
        registrar_evento("renombrado", f"{event.src_path} → {event.dest_path}")

    def on_modified(self, event):
        print(f" Modificado: {event.src_path}")
        registrar_evento("modificado", event.src_path)

    def on_created(self, event):
        print(f" Creado: {event.src_path}")
        registrar_evento("creado", event.src_path)

    def on_deleted(self, event):
        print(f" Eliminado: {event.src_path}")
        registrar_evento("eliminado", event.src_path)

# Detección USB
def detectar_usb():
    pythoncom.CoInitialize()
    w = wmi.WMI()
    watcher = w.Win32_USBHub.watch_for("creation")
    while True:
        dispositivo = watcher()
        print(f" USB conectada: {dispositivo.DeviceID}")
        registrar_evento("usb_conectada", dispositivo.DeviceID)

def detectar_usb_desconectada():
    pythoncom.CoInitialize()
    w = wmi.WMI()
    watcher = w.Win32_USBHub.watch_for("deletion")
    while True:
        dispositivo = watcher()
        print(f" USB desconectada: {dispositivo.DeviceID}")
        registrar_evento("usb_desconectada", dispositivo.DeviceID)

# Crear carpetas si no existen
for carpeta in ['reportes']:
    os.makedirs(carpeta, exist_ok=True)

# Iniciar observador
observador = Observer()
observador.schedule(EventosHandler(), path='reportes/', recursive=True)
observador.start()

# Hilos USB
threading.Thread(target=detectar_usb, daemon=True).start()
threading.Thread(target=detectar_usb_desconectada, daemon=True).start()

# Mantener activo
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    observador.stop()
observador.join()
