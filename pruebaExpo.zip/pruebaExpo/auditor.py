# auditor.py
import tkinter as tk
from tkinter import ttk
from db import consultar_por_tipo, exportar_csv

def mostrar_eventos():
    tipo = tipo_var.get()
    eventos = consultar_por_tipo(tipo)
    for row in tree.get_children():
        tree.delete(row)
    for e in eventos:
        tree.insert('', 'end', values=e)

def exportar():
    exportar_csv()
    status_var.set("Exportado a eventos_exportados.csv")

root = tk.Tk()
root.title("Auditor de Eventos")

tipo_var = tk.StringVar()
status_var = tk.StringVar()

tk.Label(root, text="Tipo de evento:").pack()
tk.Entry(root, textvariable=tipo_var).pack()
tk.Button(root, text="Consultar", command=mostrar_eventos).pack()
tk.Button(root, text="Exportar CSV", command=exportar).pack()
tk.Label(root, textvariable=status_var).pack()

tree = ttk.Treeview(root, columns=('ID', 'Tipo', 'Ruta', 'Fecha'), show='headings')
for col in ('ID', 'Tipo', 'Ruta', 'Fecha'):
    tree.heading(col, text=col)
tree.pack(fill='both', expand=True)

root.mainloop()
