import sqlite3
from datetime import datetime
import csv

# Función segura para registrar eventos desde cualquier hilo
def registrar_evento(tipo, ruta):
    conn = sqlite3.connect('eventos.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS eventos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT,
            ruta TEXT,
            fecha TEXT
        )
    ''')
    cursor.execute('INSERT INTO eventos (tipo, ruta, fecha) VALUES (?, ?, ?)',
                   (tipo, ruta, datetime.now().isoformat()))
    conn.commit()
    conn.close()

# Consultar eventos por tipo
def consultar_por_tipo(tipo):
    conn = sqlite3.connect('eventos.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM eventos WHERE tipo = ? ORDER BY fecha DESC', (tipo,))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

# Consultar eventos por rango de fechas 
def consultar_por_rango(inicio, fin):
    conn = sqlite3.connect('eventos.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM eventos WHERE fecha BETWEEN ? AND ? ORDER BY fecha DESC', (inicio, fin))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

# Exportar todos los eventos a CSV
def exportar_csv(nombre_archivo='eventos_exportados.csv'):
    conn = sqlite3.connect('eventos.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM eventos ORDER BY fecha DESC')
    filas = cursor.fetchall()
    with open(nombre_archivo, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ID', 'Tipo', 'Ruta', 'Fecha'])
        writer.writerows(filas)
    conn.close()
    print(f"Exportado a {nombre_archivo}")

# Ejecución directa para pruebas
if __name__ == '__main__':
    conn = sqlite3.connect('eventos.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM eventos ORDER BY id ASC')
    for fila in cursor.fetchall():
        print(fila)
    conn.close()
